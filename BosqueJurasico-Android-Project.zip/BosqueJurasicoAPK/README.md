# Bosque Jurásico V5 — Android WebView APK project

This project wraps the existing game HTML in an Android fullscreen landscape WebView. The original game is included at `app/src/main/assets/index.html`.


## Build the APK online (no Android Studio needed)
1. Create a GitHub account if you don't have one and make a new repository.
2. Upload the contents of this project ZIP to the repository (keep folders such as `app` and `.github`).
3. Open the repository's **Actions** tab.
4. Select **Build Bosque Jurásico APK** and click **Run workflow**.
5. When it finishes successfully, open that workflow run and download the artifact named **Bosque-Jurasico-APK**. Inside is `app-debug.apk`.
6. Transfer the APK to your phone and install it. Android may ask to allow installation from that source.

The game still loads Three.js from its CDN, so the first launch/gameplay requires an internet connection.
